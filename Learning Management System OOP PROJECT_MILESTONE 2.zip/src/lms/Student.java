
package lms;

import java.util.ArrayList;
import java.util.List;

public class Student extends User {
    private Wallet wallet;
    private String address;
    private Gender gender;
    private List<Course> enrolledCourses;

    public Student(String username, String password, String dateOfBirth, double balance, String address, Gender gender) {
        super(username, password, dateOfBirth);
        this.wallet = new Wallet(balance);
        this.address = address;
        this.gender = gender;
        this.enrolledCourses = new ArrayList<>();
    }

    public boolean enrollInCourse(Course course) {
        if (wallet.getBalance() >= course.getPrice()) {
            enrolledCourses.add(course);
            wallet.debit(course.getPrice());
            course.getInstructor().getWallet().credit(course.getPrice());
            course.addStudent(this);
            return true;
        }
        return false;
    }

    public void submitAssignment(Assignment assignment, String submission) {
        assignment.submit(this, submission);
    }

    public Wallet getWallet() {
        return wallet;
    }

    public List<Course> getEnrolledCourses() {
        return enrolledCourses;
    }

    @Override
    public void dashboard() {
        System.out.println("Student Dashboard for: " + username);
    }
}
