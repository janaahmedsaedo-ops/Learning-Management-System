import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.Set;

public class Room {
    private String roomId;
    private String name;
    private int capacity;
    private String location;
    private Set<String> reservedEventIds = new HashSet<>();

    public Room(String roomId, String name, int capacity, String location) {
        this.roomId = roomId;
        this.name = name;
        this.capacity = capacity;
        this.location = location;
    }

    public String getRoomId() { return roomId; }
    public String getName() { return name; }
    public int getCapacity() { return capacity; }
    public String getLocation() { return location; }

    public boolean isAvailable(LocalDateTime start, int duration) { return true; }
    public void reserve(EventContract e) { reservedEventIds.add(e.getEventId()); }
    public void release(EventContract e) { reservedEventIds.remove(e.getEventId()); }

    @Override public String toString() { return name + " (" + capacity + ") - " + location; }
}
