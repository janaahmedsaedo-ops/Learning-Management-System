
package lms;

import java.util.List;

public class Admin extends User {
    private String role;
    private int workingHours;

    public Admin(String username, String password, String dateOfBirth, String role, int workingHours) {
        super(username, password, dateOfBirth);
        this.role = role;
        this.workingHours = workingHours;
    }

    public void showAllCourses() {
        System.out.println("Courses:");
        for (Course c : Database.courses)
            System.out.println("- " + c.getTitle());
    }

    public void showAllStudents() {
        System.out.println("Students:");
        for (Student s : Database.students)
            System.out.println("- " + s.getUsername());
    }

    public void showAllInstructors() {
        System.out.println("Instructors:");
        for (Instructor i : Database.instructors)
            System.out.println("- " + i.getUsername());
    }

    @Override
    public void dashboard() {
        System.out.println("Admin Dashboard for: " + username);
    }
}
