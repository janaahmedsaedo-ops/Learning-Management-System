
package gui;

import javafx.fxml.FXML;
import javafx.scene.control.TextArea;
import lms.*;

public class AdminDashboardController {

    @FXML private TextArea outputArea;

    @FXML
    public void onViewStudents() {
        StringBuilder sb = new StringBuilder("All Students:\n");
        for (Student s : Database.students) {
            sb.append(" - ").append(s.getUsername()).append(" (").append(s.getAddress()).append(")\n");
        }
        outputArea.setText(sb.toString());
    }

    @FXML
    public void onViewInstructors() {
        StringBuilder sb = new StringBuilder("All Instructors:\n");
        for (Instructor i : Database.instructors) {
            sb.append(" - ").append(i.getUsername()).append(" | ").append(i.getSpecialization()).append("\n");
        }
        outputArea.setText(sb.toString());
    }

    @FXML
    public void onViewCourses() {
        StringBuilder sb = new StringBuilder("All Courses:\n");
        for (Course c : Database.courses) {
            sb.append(" - ").append(c.getTitle()).append(" | Instructor: ").append(c.getInstructor().getUsername()).append("\n");
        }
        outputArea.setText(sb.toString());
    }
}
