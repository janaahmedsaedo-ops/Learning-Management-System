public interface Attendee {
    String getAttendeeId();
    String getName();
    String getEmail();
    void registerForEvent(EventContract e);
    void cancelRegistration(EventContract e);
    void viewSchedule();
}
