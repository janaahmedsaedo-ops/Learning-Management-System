import java.time.LocalDateTime;
import java.util.*;

public class Database {
    public static List<Student> students = new ArrayList<>();
    public static List<Instructor> instructors = new ArrayList<>();
    public static List<Admin> admins = new ArrayList<>();
    public static List<Course> courses = new ArrayList<>();
    public static List<Category> categories = new ArrayList<>();
    public static List<Room> rooms = new ArrayList<>();

    static {
        Category cat1 = new Category("Programming");
        Category cat2 = new Category("Math");
        categories.add(cat1); categories.add(cat2);

        Room r1 = new Room("R-1", "Room A", 40, "Building 1");
        Room r2 = new Room("R-2", "Room B", 25, "https://example.com/room-b");
        rooms.add(r1); rooms.add(r2);

        Instructor inst1 = new Instructor("ORG-1", "John Doe", "john@lms.com",
                "john", "1234", "1980-05-01", "Java");
        instructors.add(inst1);

        Student stu1 = new Student("ATT-1", "Alice Smith", "alice@mail.com",
                "alice", "pass", "2000-01-01", "123 St", Gender.FEMALE, 1000);
        students.add(stu1);

        Admin admin1 = new Admin("ADM-1", "Super Admin", "admin@lms.com",
                "admin", "admin", "1970-01-01", "Super Admin", 40);
        admins.add(admin1);

        inst1.createCourse("EVT-1", "Java Basics", "Intro to Java", LocalDateTime.now().plusDays(7), 120, 200, cat1);
        inst1.createCourse("EVT-2", "Algebra I", "Fundamentals of Algebra", LocalDateTime.now().plusDays(10), 90, 150, cat2);

        if (!courses.isEmpty()) { courses.get(0).setRoom(r1); }
    }
}
