
package lms;

import java.util.ArrayList;
import java.util.List;

public class Course {
    private String title;
    private String description;
    private double price;
    private Instructor instructor;
    private Category category;
    private List<Student> enrolledStudents;
    private List<Assignment> assignments;

    public Course(String title, String description, double price, Instructor instructor, Category category) {
        this.title = title;
        this.description = description;
        this.price = price;
        this.instructor = instructor;
        this.category = category;
        this.enrolledStudents = new ArrayList<>();
        this.assignments = new ArrayList<>();
        instructor.addCourse(this);
    }

    public void addStudent(Student student) {
        enrolledStudents.add(student);
    }

    public void addAssignment(Assignment assignment) {
        assignments.add(assignment);
    }

    public List<Student> getEnrolledStudents() {
        return enrolledStudents;
    }

    public List<Assignment> getAssignments() {
        return assignments;
    }

    public String getTitle() {
        return title;
    }

    public double getPrice() {
        return price;
    }

    public Instructor getInstructor() {
        return instructor;
    }

    public Category getCategory() {
        return category;
    }
}
