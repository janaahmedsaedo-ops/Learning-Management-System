import java.time.LocalDateTime;

public interface EventContract {
    String getEventId();
    String getTitle();
    String getDescription();
    LocalDateTime getDateTime();
    int getDurationMinutes();
    Room getRoom();
    Organizer getOrganizer();

    void addAttendee(Attendee a);
    void removeAttendee(Attendee a);
    void assignRoom(Room r);
}
