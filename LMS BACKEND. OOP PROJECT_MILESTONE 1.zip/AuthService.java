public class AuthService {
    public static User login(String username, String password) {
        for (Student s : Database.students) if (s.getUsername().equals(username) && s.getPassword().equals(password)) return s;
        for (Instructor i : Database.instructors) if (i.getUsername().equals(username) && i.getPassword().equals(password)) return i;
        for (Admin a : Database.admins) if (a.getUsername().equals(username) && a.getPassword().equals(password)) return a;
        System.out.println("Login failed"); return null;
    }

    public static Student registerStudent(String attendeeId, String name, String email,
                                          String username, String password, String dob,
                                          String address, Gender gender, double balance) {
        Student s = new Student(attendeeId, name, email, username, password, dob, address, gender, balance);
        Database.students.add(s); System.out.println("Student registered: " + username); return s;
    }

    public static Instructor registerInstructor(String organizerId, String name, String email,
                                                String username, String password, String dob, String specialization) {
        Instructor i = new Instructor(organizerId, name, email, username, password, dob, specialization);
        Database.instructors.add(i); System.out.println("Instructor registered: " + username); return i;
    }

    public static Admin registerAdmin(String adminId, String name, String email,
                                      String username, String password, String dob, String role, int hours) {
        Admin a = new Admin(adminId, name, email, username, password, dob, role, hours);
        Database.admins.add(a); System.out.println("Admin registered: " + username); return a;
    }
}
