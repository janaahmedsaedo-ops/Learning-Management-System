
package gui;

import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.TextArea;
import lms.Course;
import lms.Database;
import lms.Student;

public class StudentDashboardController {

    @FXML private TextArea outputArea;

    private Student student;

    public void setStudent(Student student) {
        this.student = student;
    }

    @FXML
    public void onViewCourses() {
        StringBuilder sb = new StringBuilder();
        for (Course c : student.getEnrolledCourses()) {
            sb.append("Course: ").append(c.getTitle()).append(" | Instructor: ")
              .append(c.getInstructor().getUsername()).append("\n");
        }
        outputArea.setText(sb.toString());
    }

    @FXML
    public void onSubmitAssignment() {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setContentText("Submit Assignment feature not fully implemented.");
        alert.showAndWait();
    }
}
