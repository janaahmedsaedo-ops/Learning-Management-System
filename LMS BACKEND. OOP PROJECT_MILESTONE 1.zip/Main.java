public class Main {
    public static void main(String[] args) {
        User user = AuthService.login("alice", "pass");
        if (user != null) { System.out.println("Logged in as: " + user.getUsername()); user.dashboard(); }

        Instructor john = Database.instructors.get(0);
        System.out.println("Available courses: " + john.listAvailableCourses());
        System.out.println("My courses: " + john.listMyCourses());
        System.out.println("My students: " + john.listMyStudents());

        Student alice = Database.students.get(0);
        if (!Database.courses.isEmpty()) {
            EventContract e = Database.courses.get(0);
            alice.registerForEvent(e);
        }

        if (Database.courses.size() > 1) {
            Admin admin = Database.admins.get(0);
            admin.assignRoom(Database.courses.get(1), Database.rooms.get(1));
        }

        john.cancelEvent("EVT-2");
        System.out.println("Courses now: " + Database.courses);
    }
}
