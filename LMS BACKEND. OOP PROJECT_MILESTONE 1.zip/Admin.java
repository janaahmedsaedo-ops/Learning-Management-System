public class Admin extends User implements AdminManager {
    private String adminId;
    private String name;
    private String email;
    private String role;
    private int workingHours;

    public Admin(String adminId, String name, String email,
                 String username, String password, String dateOfBirth, String role, int workingHours) {
        super(username, password, dateOfBirth);
        this.adminId = adminId; this.name = name; this.email = email;
        this.role = role; this.workingHours = workingHours;
    }

    public void showAll() {
        System.out.println("All Courses: " + Database.courses);
        System.out.println("All Students: " + Database.students);
        System.out.println("All Instructors: " + Database.instructors);
        System.out.println("All Rooms: " + Database.rooms);
    }

    @Override public String getAdminId() { return adminId; }
    @Override public String getName() { return name; }
    @Override public String getEmail() { return email; }
    @Override public void addEvent(EventContract e) { if (e instanceof Course c && !Database.courses.contains(c)) Database.courses.add(c); }
    @Override public void removeEvent(String eventId) { Database.courses.removeIf(c -> c.getEventId().equals(eventId)); }
    @Override public void assignRoom(EventContract e, Room r) { e.assignRoom(r); }
    @Override public void manageUsers() { System.out.println("Users: students=" + Database.students.size() + ", instructors=" + Database.instructors.size()); }

    @Override public void dashboard() { showAll(); }
}
