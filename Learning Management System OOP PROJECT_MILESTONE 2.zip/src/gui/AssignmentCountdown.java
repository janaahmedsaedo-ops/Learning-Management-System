
package gui;

import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import java.time.Duration;
import java.time.LocalDateTime;
import java.util.Timer;
import java.util.TimerTask;

public class AssignmentCountdown {

    @FXML private Label countdownLabel;

    private final LocalDateTime deadline = LocalDateTime.now().plusMinutes(5); // example deadline

    public void startCountdown() {
        Timer timer = new Timer();
        timer.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                Duration duration = Duration.between(LocalDateTime.now(), deadline);
                if (!duration.isNegative() && !duration.isZero()) {
                    long mins = duration.toMinutes();
                    long secs = duration.minusMinutes(mins).getSeconds();
                    Platform.runLater(() -> countdownLabel.setText("Deadline in: " + mins + "m " + secs + "s"));
                } else {
                    Platform.runLater(() -> countdownLabel.setText("Deadline passed!"));
                    timer.cancel();
                }
            }
        }, 0, 1000);
    }
}
