public class Wallet {
    private double balance;
    public Wallet(double initialBalance) {
        if (initialBalance < 0) throw new IllegalArgumentException("Initial balance cannot be negative");
        this.balance = initialBalance;
    }
    public double getBalance() { return balance; }
    public void debit(double amount) {
        if (amount < 0) throw new IllegalArgumentException("Amount cannot be negative");
        if (balance < amount) throw new IllegalStateException("Insufficient balance");
        balance -= amount;
    }
    public void credit(double amount) {
        if (amount < 0) throw new IllegalArgumentException("Amount cannot be negative");
        balance += amount;
    }
}
