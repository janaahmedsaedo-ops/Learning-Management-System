public interface Organizer {
    String getOrganizerId();
    String getName();
    String getEmail();
    void createEvent(EventContract e);
    void editEvent(EventContract e);
    void cancelEvent(String eventId);
}
