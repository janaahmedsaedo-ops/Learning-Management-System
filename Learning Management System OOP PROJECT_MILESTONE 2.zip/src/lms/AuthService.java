
package lms;

public class AuthService {

    public static User login(String username, String password) {
        for (Student s : Database.students)
            if (s.getUsername().equals(username) && s.getPassword().equals(password)) return s;
        for (Instructor i : Database.instructors)
            if (i.getUsername().equals(username) && i.getPassword().equals(password)) return i;
        for (Admin a : Database.admins)
            if (a.getUsername().equals(username) && a.getPassword().equals(password)) return a;

        System.out.println("Login failed: invalid credentials");
        return null;
    }

    public static boolean isUsernameTaken(String username) {
        return Database.students.stream().anyMatch(s -> s.getUsername().equals(username)) ||
               Database.instructors.stream().anyMatch(i -> i.getUsername().equals(username)) ||
               Database.admins.stream().anyMatch(a -> a.getUsername().equals(username));
    }

    public static boolean registerStudent(String username, String password, String dob, double balance, String address, Gender gender) {
        if (!isUsernameTaken(username)) {
            Student newStudent = new Student(username, password, dob, balance, address, gender);
            Database.students.add(newStudent);
            return true;
        }
        return false;
    }

    public static boolean registerInstructor(String username, String password, String dob, String specialization) {
        if (!isUsernameTaken(username)) {
            Instructor newInstructor = new Instructor(username, password, dob, specialization);
            Database.instructors.add(newInstructor);
            return true;
        }
        return false;
    }
}
