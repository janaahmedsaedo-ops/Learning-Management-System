import java.util.*;

public class Student extends User implements Attendee {
    private String attendeeId;
    private String name;
    private String email;
    private String address;
    private Gender gender;
    private Wallet wallet;
    private List<Course> enrolledCourses;

    public Student(String attendeeId, String name, String email,
                   String username, String password, String dateOfBirth,
                   String address, Gender gender, double balance) {
        super(username, password, dateOfBirth);
        this.attendeeId = attendeeId;
        this.name = name;
        this.email = email;
        this.address = address;
        this.gender = gender;
        this.wallet = new Wallet(balance);
        this.enrolledCourses = new ArrayList<>();
    }

    public void enroll(Course course) {
        if (!course.isAvailable()) { System.out.println("Course not available."); return; }
        if (enrolledCourses.contains(course)) { System.out.println("Already enrolled in this course."); return; }
        if (wallet.getBalance() >= course.getPrice()) {
            wallet.debit(course.getPrice());
            course.getInstructor().creditWallet(course.getPrice());
            enrolledCourses.add(course);
            course.addStudent(this);
            System.out.println("Enrolled successfully.");
        } else { System.out.println("Insufficient balance."); }
    }

    public void submitAssignment(Assignment assignment) { assignment.submit(this); }

    public Wallet getWallet() { return wallet; }
    public String getAddress() { return address; }
    public Gender getGender() { return gender; }
    public List<Course> getEnrolledCourses() { return Collections.unmodifiableList(enrolledCourses); }

    // Attendee mapping
    @Override public String getAttendeeId() { return attendeeId; }
    @Override public String getName() { return name; }
    @Override public String getEmail() { return email; }
    @Override public void registerForEvent(EventContract e) { if (e instanceof Course) enroll((Course)e); }
    @Override public void cancelRegistration(EventContract e) { if (e instanceof Course) { Course c=(Course)e; enrolledCourses.remove(c); System.out.println("Registration cancelled."); } }
    @Override public void viewSchedule() { System.out.println("Enrolled courses: " + enrolledCourses); }

    @Override public void dashboard() { System.out.println("Student Dashboard"); }
}
