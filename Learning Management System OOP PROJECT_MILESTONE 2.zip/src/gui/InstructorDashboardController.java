
package gui;

import javafx.fxml.FXML;
import javafx.scene.control.TextArea;
import lms.*;

public class InstructorDashboardController {

    @FXML private TextArea outputArea;

    private Instructor instructor;

    public void setInstructor(Instructor instructor) {
        this.instructor = instructor;
    }

    @FXML
    public void onMyCourses() {
        StringBuilder sb = new StringBuilder();
        for (Course c : Database.courses) {
            if (c.getInstructor().equals(instructor)) {
                sb.append("Course: ").append(c.getTitle()).append("\n");
            }
        }
        outputArea.setText(sb.toString());
    }

    @FXML
    public void onEnrolledStudents() {
        StringBuilder sb = new StringBuilder();
        for (Course c : Database.courses) {
            if (c.getInstructor().equals(instructor)) {
                sb.append("Course: ").append(c.getTitle()).append("\n");
                for (Student s : c.getEnrolledStudents()) {
                    sb.append(" - Student: ").append(s.getUsername()).append("\n");
                }
            }
        }
        outputArea.setText(sb.toString());
    }
}
