
package lms;

import java.util.ArrayList;
import java.util.List;

public class Database {
    public static List<Student> students = new ArrayList<>();
    public static List<Instructor> instructors = new ArrayList<>();
    public static List<Admin> admins = new ArrayList<>();
    public static List<Course> courses = new ArrayList<>();
    public static List<Category> categories = new ArrayList<>();

    static {
        // Dummy data for initial use
        Instructor i1 = new Instructor("instructor1", "pass123", "1985-03-20", "Math");
        instructors.add(i1);
        Category c1 = new Category("Mathematics");
        categories.add(c1);
        Course course1 = new Course("Algebra Basics", "Learn algebra", 100.0, i1, c1);
        courses.add(course1);

        Student s1 = new Student("student1", "pass123", "2000-01-01", 150.0, "Cairo", Gender.MALE);
        students.add(s1);

        Admin a1 = new Admin("admin1", "admin123", "1970-06-15", "Manager", 40);
        admins.add(a1);
    }
}
