import java.time.LocalDateTime;
import java.util.*;

public class Course implements EventContract {
    private String eventId;
    private String title;
    private String description;
    private LocalDateTime dateTime;
    private int durationMinutes;
    private Instructor instructor;
    private double price;
    private Category category;
    private Room room;
    private List<Student> students;
    private List<Assignment> assignments;
    private boolean available = true;

    public Course(String eventId, String title, String description, LocalDateTime dateTime, int durationMinutes,
                  Instructor instructor, double price, Category category) {
        if (price < 0) throw new IllegalArgumentException("Price cannot be negative");
        this.eventId = eventId;
        this.title = title;
        this.description = description;
        this.dateTime = dateTime;
        this.durationMinutes = durationMinutes;
        this.instructor = instructor;
        this.price = price;
        this.category = category;
        this.students = new ArrayList<>();
        this.assignments = new ArrayList<>();
    }

    // CRUD-ish
    public void updateTitle(String newTitle) { this.title = newTitle; }
    public void updatePrice(double newPrice) { if (newPrice < 0) throw new IllegalArgumentException("Price cannot be negative"); this.price = newPrice; }
    public void updateCategory(Category newCategory) { this.category = newCategory; }
    public void toggleAvailability() { this.available = !this.available; }
    public void deleteAssignment(Assignment a) { assignments.remove(a); }
    public void deleteCourse() { Database.courses.remove(this); }
    public void setRoom(Room room) { this.room = room; }

    // Associations
    public void addStudent(Student student) { if (!students.contains(student)) students.add(student); }
    public void addAssignment(Assignment assignment) { assignments.add(assignment); }

    // Getters
    public String getTitle() { return title; }
    public Instructor getInstructor() { return instructor; }
    public double getPrice() { return price; }
    public Category getCategory() { return category; }
    public Room getRoom() { return room; }
    public boolean isAvailable() { return available; }
    public List<Student> getStudents() { return Collections.unmodifiableList(students); }
    public List<Assignment> getAssignments() { return Collections.unmodifiableList(assignments); }
    public boolean hasStudent(Student s) { return students.contains(s); }

    @Override public String toString() { return title + " by " + instructor.getUsername() + (room != null ? " @ " + room.getName() : ""); }

    // EventContract implementation
    @Override public String getEventId() { return eventId; }
    @Override public String getDescription() { return description; }
    @Override public LocalDateTime getDateTime() { return dateTime; }
    @Override public int getDurationMinutes() { return durationMinutes; }
    @Override public Organizer getOrganizer() { return instructor; }
    @Override public void addAttendee(Attendee a) { if (a instanceof Student) addStudent((Student)a); }
    @Override public void removeAttendee(Attendee a) { if (a instanceof Student) students.remove((Student)a); }
    @Override public void assignRoom(Room r) { setRoom(r); }
}
