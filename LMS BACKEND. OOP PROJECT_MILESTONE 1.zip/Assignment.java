import java.util.*;

public class Assignment {
    private String title;
    private String deadline;
    private Course course;
    private Map<Student, String> submissions = new HashMap<>();

    public Assignment(String title, String deadline, Course course) {
        this.title = title;
        this.deadline = deadline;
        this.course = course;
    }

    public void updateTitle(String newTitle) { this.title = newTitle; }
    public void updateDeadline(String newDeadline) { this.deadline = newDeadline; }
    public void delete() { course.deleteAssignment(this); }

    public void submit(Student student) {
        if (!course.hasStudent(student)) {
            System.out.println("You are not enrolled in this course.");
            return;
        }
        submissions.put(student, "Submitted");
        System.out.println("Assignment submitted.");
    }

    public String getTitle() { return title; }
    public String getDeadline() { return deadline; }
    public Course getCourse() { return course; }
}
