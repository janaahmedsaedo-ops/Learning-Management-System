
package lms;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;

public class Assignment {
    private String title;
    private String description;
    private LocalDate dueDate;
    private Map<Student, String> submissions = new HashMap<>();

    public Assignment(String title, String description, LocalDate dueDate) {
        this.title = title;
        this.description = description;
        this.dueDate = dueDate;
    }

    public void submit(Student student, String answer) {
        if (LocalDate.now().isBefore(dueDate) || LocalDate.now().isEqual(dueDate)) {
            submissions.put(student, answer);
        } else {
            System.out.println("Deadline missed. Cannot submit assignment.");
        }
    }

    public String getTitle() {
        return title;
    }

    public LocalDate getDueDate() {
        return dueDate;
    }
}
