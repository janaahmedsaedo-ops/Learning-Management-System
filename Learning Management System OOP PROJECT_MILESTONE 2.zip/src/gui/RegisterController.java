
package gui;

import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.event.ActionEvent;
import lms.*;

public class RegisterController {

    @FXML private TextField usernameField;
    @FXML private PasswordField passwordField;
    @FXML private TextField dobField;
    @FXML private TextField addressField;
    @FXML private TextField balanceField;
    @FXML private ChoiceBox<Gender> genderBox;

    @FXML
    public void initialize() {
        genderBox.getItems().setAll(Gender.values());
    }

    @FXML
    protected void onRegisterStudent(ActionEvent event) {
        try {
            String username = usernameField.getText();
            String password = passwordField.getText();
            String dob = dobField.getText();
            String address = addressField.getText();
            double balance = Double.parseDouble(balanceField.getText());
            Gender gender = genderBox.getValue();

            boolean success = AuthService.registerStudent(username, password, dob, balance, address, gender);
            Alert alert = new Alert(success ? Alert.AlertType.INFORMATION : Alert.AlertType.ERROR);
            alert.setHeaderText(success ? "Success" : "Error");
            alert.setContentText(success ? "Student registered successfully!" : "Username already taken.");
            alert.showAndWait();
        } catch (Exception e) {
            Alert errorAlert = new Alert(Alert.AlertType.ERROR);
            errorAlert.setHeaderText("Input Error");
            errorAlert.setContentText("Please enter all fields correctly.");
            errorAlert.showAndWait();
        }
    }
}
