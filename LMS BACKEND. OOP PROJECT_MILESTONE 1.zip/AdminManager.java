public interface AdminManager {
    String getAdminId();
    String getName();
    String getEmail();
    void addEvent(EventContract e);
    void removeEvent(String eventId);
    void assignRoom(EventContract e, Room r);
    void manageUsers();
}
