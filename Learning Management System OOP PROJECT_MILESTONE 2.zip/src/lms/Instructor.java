
package lms;

import java.util.ArrayList;
import java.util.List;

public class Instructor extends User {
    private String specialization;
    private Wallet wallet;
    private List<Course> teachingCourses;

    public Instructor(String username, String password, String dateOfBirth, String specialization) {
        super(username, password, dateOfBirth);
        this.specialization = specialization;
        this.wallet = new Wallet(0.0);
        this.teachingCourses = new ArrayList<>();
    }

    public void addCourse(Course course) {
        teachingCourses.add(course);
    }

    public List<Course> getTeachingCourses() {
        return teachingCourses;
    }

    public Wallet getWallet() {
        return wallet;
    }

    public String getSpecialization() {
        return specialization;
    }

    @Override
    public void dashboard() {
        System.out.println("Instructor Dashboard for: " + username);
    }
}
