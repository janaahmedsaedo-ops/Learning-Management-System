import java.util.*;
import java.util.stream.Collectors;

public class Instructor extends User implements Organizer {
    private String organizerId;
    private String name;
    private String email;
    private String specialization;
    private Wallet wallet;
    private List<Course> coursesTeaching;

    public Instructor(String organizerId, String name, String email,
                      String username, String password, String dateOfBirth, String specialization) {
        super(username, password, dateOfBirth);
        this.organizerId = organizerId;
        this.name = name;
        this.email = email;
        this.specialization = specialization;
        this.wallet = new Wallet(0);
        this.coursesTeaching = new ArrayList<>();
    }

    public void createCourse(String eventId, String title, String description, java.time.LocalDateTime when,
                             int durationMinutes, double price, Category category) {
        Course course = new Course(eventId, title, description, when, durationMinutes, this, price, category);
        Database.courses.add(course);
        coursesTeaching.add(course);
    }

    public void createAssignment(Course course, String title, String deadline) {
        if (!coursesTeaching.contains(course)) { System.out.println("You are not teaching this course."); return; }
        Assignment assignment = new Assignment(title, deadline, course);
        course.addAssignment(assignment);
    }

    public void creditWallet(double amount) { wallet.credit(amount); }

    public List<Course> listAvailableCourses() { return Database.courses.stream().filter(Course::isAvailable).collect(Collectors.toList()); }
    public List<Course> listMyCourses() { return new ArrayList<>(coursesTeaching); }
    public Map<Course, List<Student>> listMyStudents() {
        Map<Course, List<Student>> map = new HashMap<>();
        for (Course c : coursesTeaching) map.put(c, c.getStudents());
        return map;
    }

    public Wallet getWallet() { return wallet; }
    public String getSpecialization() { return specialization; }

    // Organizer
    @Override public String getOrganizerId() { return organizerId; }
    @Override public String getName() { return name; }
    @Override public String getEmail() { return email; }
    @Override public void createEvent(EventContract e) { if (e instanceof Course) { Course c=(Course)e; if (!coursesTeaching.contains(c)) coursesTeaching.add(c); if (!Database.courses.contains(c)) Database.courses.add(c);} }
    @Override public void editEvent(EventContract e) { System.out.println("Event edited: " + e.getTitle()); }
    @Override public void cancelEvent(String eventId) { Database.courses.removeIf(c -> c.getEventId().equals(eventId) && coursesTeaching.remove(c)); }

    @Override public void dashboard() { System.out.println("Instructor Dashboard"); }
}
